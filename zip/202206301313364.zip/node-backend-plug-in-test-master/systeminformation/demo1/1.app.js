const si = require("systeminformation");
// si.cpu()
//   .then((data) => {
//     console.log(data);
//   })
//   .catch((err) => {
//     console.log(err);
//   });

// si.cpu()
//   .then((data) => {
//     console.log("CPU Information:");
//     console.log("- manufucturer: " + data.manufacturer);
//     console.log("- brand: " + data.brand);
//     console.log("- speed: " + data.speed);
//     console.log("- cores: " + data.cores);
//     console.log("- physical cores: " + data.physicalCores);
//     console.log("...");
//   })
//   .catch((error) => console.error(error));

const cpuData = async () => {
  const data = await si.cpu();
  console.log(data);
};
// cpuData();
// console.log(si.version());
// console.log(si.time());

// valueObj = {
//   cpu: "*",
//   osInfo: "*",
//   system: "*",
// };
// si.get(valueObj).then((data) => console.log(data));

// valueObject = {
//   processLoad: "(postgres) pids, cpu",
// };
// si.get(valueObject).then((data) => console.log(data));
// valueObject = {
//   networkInterfaces: "*",
// };
// si.get(valueObject).then((data) => console.log(data));
// si.system().then((data) => console.log(data));
// si.uuid().then((data) => console.log(data));
// si.bios().then((data) => console.log(data));
// si.baseboard().then((data) => console.log(data));
// si.cpuFlags().then((data) => console.log(data));
// si.cpuCache().then(data => console.log(data));
// si.cpuCurrentSpeed().then((data) => console.log(data));
// si.cpuTemperature().then((data) => console.log(data));

// setInterval(() => {
//   si.mem().then((data) => {
//     used = data.used;
//     //换算成MB
//     used = used / 1024 / 1024 / 1024;
//     console.log(used.toFixed(2) + "GB");
//   });
// }, 1000);
// si.memLayout().then((data) => console.log(data));
// si.battery().then((data) => console.log(data));
// si.battery().then((data) => console.log(data));
// si.graphics().then((data) => console.log(data));
// si.osInfo().then((data) => console.log(data));
// si.versions("npm,node,powershell").then((data) => console.log(data));
// si.users().then((data) => console.log(data));
// si.currentLoad().then((data) => console.log(data));
// si.diskLayout().then((data) => console.log(data));
// si.blockDevices().then((data) => console.log(data));
// si.usb().then((data) => console.log(data));
// si.printer().then((data) => console.log(data));
// si.audio().then((data) => console.log(data));
// si.networkInterfaces().then((data) => console.log(data));
// si.networkInterfaces("default").then((data) => console.log(data));
// si.networkInterfaceDefault().then((data) => console.log(data));
// si.networkGatewayDefault().then((data) => console.log(data));
// si.networkConnections().then((data) => console.log(data));
// setInterval(function () {
//   si.networkStats().then((data) => {
//     console.log(data);
//   });
// }, 1000);
