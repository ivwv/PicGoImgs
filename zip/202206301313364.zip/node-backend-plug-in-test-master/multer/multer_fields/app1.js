const express = require("express");
const multer = require("multer");
const app = express();
const iconv = require("iconv-lite");
const cors = require("cors");
const bodyParser = require("body-parser");
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(function (req, res, next) {
  if (req.method === "POST") {
    if (req.headers["content-type"] === "application/json") {
      // req.file = iconv.decode(req.file.originalname, "utf-8");
      for (let i = 0; i < req.files["avatar"].length; i++) {
        req.files["avatar"][i].originalname = iconv.decode(
          req.files["avatar"][i].originalname,
          "utf-8"
        );
      }
      for (let i = 0; i < req.files["gallery"].length; i++) {
        req.files["gallery"][i].originalname = iconv.decode(
          req.files["gallery"][i].originalname,
          "utf-8"
        );
      }
    }
  }
  next();
});
const upload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "./uploads");
    },
    filename: function (req, file, cb) {
      const { fieldname, originalname, encoding, mimetype } = file;

      cb(null, Date.now() + "~" + iconv.decode(file.originalname, "utf-8"));
    },
  }),
});
//处理req.file.originalname 中间件
app.use((req, res, next) => {
  // for (let i = 0; i < req.files.length; i++) {
  // req.files[0].originalname = iconv.decode(req.files[0].originalname, "utf-8");
  // }
  // console.log(req.file);
  console.log("经过了中间件");
  next();
});
app.post("/upload", upload.single("file"), (req, res, next) => {
  // req.file[0].originalname = iconv.decode(req.file[0].originalname, "utf-8");

  res.send(req.file);
});
app.post("/uploads", upload.array("file", 12), (req, res, next) => {
  // iconv.decode(, "utf-8");
  var oriname = req.files[0].originalname;
  oriname = iconv.decode(oriname, "utf-8");
  console.log(oriname);
  console.log(req.files);
  // console.log();
  res.send(req.files);
  console.log(req.body);
  // console.log(req.params);
});

const cpUpload = upload.fields([
  { name: "avatar", maxCount: 3 },
  { name: "gallery", maxCount: 8 },
]);

app.post("/cool-profile", cpUpload, function (req, res, next) {
  // req.files is an object (String -> Array) where fieldname is the key, and the value is array of files
  //
  // e.g.
  //  req.files['avatar'][0] -> File
  //  req.files['gallery'] -> Array
  //
  // req.body will contain the text fields, if there were any
  console.log(req.files);
  // console.log(req.files["avatar"][0].originalname.toString());
  //将 req.files["avatar"][0].originalname 内容转换为utf-8
  // console.log(iconv.decode(req.files["avatar"][0].originalname, "utf-8"));
  res.send({
    code: 200,
    msg: "上传成功",
    avatar: req.files["avatar"],
    gallery: req.files["gallery"],
    avatar_name() {
      var arr = [];
      for (let i = 0; i < req.files["avatar"].length; i++) {
        arr.push(req.files["avatar"][i].originalname);
      }
      return arr;
    },
  });
});
app.post("/profile", upload.none(), function (req, res, next) {
  // req.body contains the text fields
  console.log(req.body);
  res.send({
    code: 200,
    msg: "上传成功",
    body: req.body,
  });
});
app.use("/uploads", express.static("uploads"));

app.listen(3000, () => {
  console.log("http://localhost:3000");
});

// const obj = {
//   name: "sz",
//   age: 21,
//   fun() {
//     // console.log("hesllo");
//     return "hello";
//   },
// };
// console.log(obj.fun());
