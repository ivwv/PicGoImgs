const path = require("path");
const fs = require("fs");
//创建文件夹
function mkdirs(dirpath, mode, callback) {
  fs.exists(dirpath, function (exists) {
    if (exists) {
      callback(dirpath);
    } else {
      //尝试创建父目录，然后再创建当前目录
      mkdirs(path.dirname(dirpath), mode, function () {
        fs.mkdir(dirpath, mode, callback);
      });
    }
  });
}
//测试
const dir = "./demo";
const file = "/test.txt";
mkdirs(dir, 0777, function () {
  console.log("创建w文件夹成功");
  createFile(dir + file, "Hello World", function () {
    console.log("创建成功");
  });
});
//创建文件
function createFile(filePath, data, callback) {
  fs.exists(filePath, function (exists) {
    if (exists) {
      callback(filePath);
    } else {
      //尝试创建父目录，然后再创建当前目录
      mkdirs(path.dirname(filePath), 0777, function () {
        fs.writeFile(filePath, data, callback);
      });
    }
  });
}
//测试
