const express = require("express");
const multer = require("multer");
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
const upload = multer({
  limits: { fileSize: 1024 * 1024 * 6 },
  fileFilter(req, file, cb) {
    const fileType = file.mimetype.split("/")[0];
    if (fileType !== "image") {
      cb(new Error("文件类型错误"));
    }
    cb(null, true);
  },
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "./server2img");
    },
    filename: function (req, file, cb) {
      const { fieldname, originalname, encoding, mimetype } = file;
      cb(null, Date.now() + file.originalname);
    },
  }),
});
app.post("/profile", upload.single("avatar"), (req, res) => {
  // req.file 是 `avatar` 文件的信息
  // req.body 将具有文本域数据，如果存在的话
  //   console.log(req.file);
  console.log("Received a request with file:");
  console.log("有新的文件上传--", req.file.path);
  res.send({
    code: 200,
    message: "ok",
    //src 为本机ip+端口号+图片路径
    // src: `http://${req.headers.host}/api/uploads/${req.file.filename}`,
    //最好存放绝对路径，
    //以后更换服务器方便管理，并且可行，src的属性可以直接找到图片
    src: "http://localhost:3000/uploads/" + req.file.filename,
    file: req.file,
  });
});
app.post("/uploadimg", upload.single("file"), (req, res) => {
  console.log("Received a request with file:");
  //   console.log("有新的文件上传--", req.file.path);
  console.log(req.file);
  res.send({
    code: 200,
    message: "ok",
    //src 为本机ip+端口号+图片路径
    // src: `http://${req.headers.host}/api/uploads/${req.file.filename}`,
    //最好存放绝对路径，
    //以后更换服务器方便管理，并且可行，src的属性可以直接找到图片

    // file: req.file,
  });
});
app.listen(3000, () => {
  console.log("http://localhost:3000");
});
