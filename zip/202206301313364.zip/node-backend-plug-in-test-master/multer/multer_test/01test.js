const express = require("express");
const multer = require("multer");
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
// const upload = multer({ dest: "uploads/" });
// const upload = multer({
//   storage: multer.diskStorage({
//     destination(req, file, cb) {
//       cb(null, "/uploads");
//       //   console.log(req);
//       //   console.log("---------");
//       //   console.log(file);
//       //   console.log("---------");
//       //   console.log(cb);
//     },
//     filename(req, file, cb) {
//       cb(null, file.originalname);
//     },
//   }),
// });
const upload = multer({
  //   limits: { fileSize: 1024 * 1024 * 5 },
  //   fileFilter(req, file, cb) {
  //     const fileType = file.mimetype.split("/")[0];
  //     if (fileType !== "image") {
  //       cb(new Error("文件类型错误"));
  //     }
  //     cb(null, true);
  //   },
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "./server2img");
    },
    filename: function (req, file, cb) {
      const { fieldname, originalname, encoding, mimetype } = file;
      cb(null, Date.now() + "~" + file.originalname);
    },
  }),
});
// const upload = multer({
//   limits: { fileSize: 1024 * 1024 * 6 },
//   fileFilter(req, file, cb) {
//     const fileType = file.mimetype.split("/")[0];
//     if (fileType !== "image") {
//       cb(new Error("文件类型错误"));
//     }
//     cb(null, true);
//   },
//   storage: multer.diskStorage({
//     destination: function (req, file, cb) {
//       cb(null, "./uploads");
//     },
//     filename: function (req, file, cb) {
//       const { fieldname, originalname, encoding, mimetype } = file;
//       cb(null, Date.now() + file.originalname);
//     },
//   }),
// });
const upload2 = multer({
  //   limits: { fileSize: 1024 * 1024 * 5 },
  //   fileFilter(req, file, cb) {
  //     const fileType = file.mimetype.split("/")[0];
  //     if (fileType !== "image") {
  //       cb(new Error("文件类型错误"));
  //     }
  //     cb(null, true);
  //   },
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "./uploads2");
    },
    filename: function (req, file, cb) {
      //获取file.originalname . 后面的字符串
      const houzui =
        "." +
        file.originalname.substring(file.originalname.lastIndexOf(".") + 1);
      // var houzui = file.originalname.split(".");
      const { fieldname, originalname, encoding, mimetype } = file;
      cb(null, Date.now() + houzui);
    },
  }),
});
app.post("/profile", upload.single("avatar"), function (req, res, next) {
  // req.file 是 `avatar` 文件的信息
  // req.body 将具有文本域数据，如果存在的话
  //   console.log(req.file);
  console.log(req.file);
  res.send({
    code: 200,
    msg: "上传成功",
    file: req.file,
  });
});

app.post(
  "/photos/upload",
  upload.array("photos", 12),
  function (req, res, next) {
    // req.files 是 `photos` 文件数组的信息
    // req.body 将具有文本域数据，如果存在的话
    console.log(req.files);
    res.send("ok");
  }
);
app.post(
  "/photos/upload2",
  upload2.array("photos2", 100),
  function (req, res, next) {
    // req.files 是 `photos` 文件数组的信息
    // req.body 将具有文本域数据，如果存在的话
    console.log(req.files);
    console.log(req.body);
    res.send({
      code: 200,
      msg: "上传成功",
      file: req.files,
    });
  }
);
app.use("/uploads", express.static(__dirname + "/uploads"));
app.use("/uploads2", express.static(__dirname + "/uploads2"));
const cpUpload = upload.fields([
  { name: "avatar", maxCount: 1 },
  { name: "gallery", maxCount: 8 },
]);
app.post("/cool-profile", cpUpload, function (req, res, next) {
  // req.files 是一个对象 (String -> Array) 键是文件名，值是文件数组
  //
  // 例如：
  //  req.files['avatar'][0] -> File
  //  req.files['gallery'] -> Array
  //
  // req.body 将具有文本域数据，如果存在的话
});

app.listen(3000, () => {
  console.log("http://localhost:3000");
});
